document.getElementById('npcForm').addEventListener('submit', function(e) {
  e.preventDefault();

  let npcHP = parseInt(document.getElementById('npcHP').value);
  let npcPearl = parseInt(document.getElementById('npcPearl').value);
  let npcGold = parseInt(document.getElementById('npcGold').value);
  let damage = parseInt(document.getElementById('damage').value);
  let ammo = parseInt(document.getElementById('ammo').value);
  let totalAmmo = parseInt(document.getElementById('totalAmmo').value);

  let shotsPerNPC = Math.ceil(npcHP / damage);
  let ammoPerNPC = shotsPerNPC * ammo;
  let maxNPC = Math.floor(totalAmmo / ammoPerNPC);

  let totalPearl = maxNPC * npcPearl;
  let totalGold = maxNPC * npcGold;
  let ammoUsed = maxNPC * ammoPerNPC;

  document.getElementById('result').innerHTML = `
    <h2>Hasil Perhitungan</h2>
    <p><strong>HP NPC:</strong> ${npcHP.toLocaleString()}</p>
    <p><strong>Reward per NPC:</strong> ${npcPearl.toLocaleString()} Pearl, ${npcGold.toLocaleString()} Gold</p>
    <hr>
    <p><strong>NPC tenggelam per 1x:</strong> ${shotsPerNPC} tembakan</p>
    <p><strong>Ammo per NPC:</strong> ${ammoPerNPC.toLocaleString()}</p>
    <hr>
    <p><strong>Total NPC tenggelam:</strong> ${maxNPC.toLocaleString()}</p>
    <p><strong>Total Pearl:</strong> ${totalPearl.toLocaleString()}</p>
    <p><strong>Total Gold:</strong> ${totalGold.toLocaleString()}</p>
    <p><strong>Ammo terpakai:</strong> ${ammoUsed.toLocaleString()}</p>
  `;
});