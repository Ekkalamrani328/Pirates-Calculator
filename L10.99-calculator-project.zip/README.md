# L10.99 NPC Calculator

Proyek kalkulator sederhana untuk menghitung hasil pertempuran dengan NPC di game Armada of Sea.

## 📂 Struktur Folder
```
L10.99-calculator-project
├── index.html
├── style.css
├── script.js
├── LICENSE
└── README.md
```

## 🚀 Cara Menjalankan
1. Clone repository atau download ZIP.
2. Buka file `index.html` di browser (desktop/mobile).

## 📜 Lisensi
Proyek ini dirilis dengan lisensi **MIT License** atas nama **L10.99**.
